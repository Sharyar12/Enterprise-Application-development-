// editimage.js

// Function to update image preview
function updatePreviewImage(input) {
    var preview = document.getElementById('previewImage');

    // Check if the preview element exists
    if (!preview) {
        console.error('Element with id "previewImage" not found.');
        return;
    }

    // Check if the input.files is available and not empty
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            // Update the src attribute of the preview image
            preview.src = e.target.result;
        };

        // Read the selected file as data URL
        reader.readAsDataURL(input.files[0]);
    } else {
        console.error('No file selected or input.files not available.');
    }
}

// Check if the file input element exists before adding the event listener
var fileInput = document.getElementById('customFile');
if (fileInput) {
    fileInput.addEventListener('change', function() {
        console.log('File input changed');
        updatePreviewImage(this);
    });
} else {
    console.error('Element with id "customFile" not found.');
}
