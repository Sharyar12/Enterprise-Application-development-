package com.example.demo.service;


import com.example.demo.model.Room;
import com.example.demo.repository.RoomR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomS {

    private final RoomR roomR;

    @Autowired
    public RoomS(RoomR roomR){this.roomR=roomR;}

    public List<Room> getRooms(){return roomR.findAll();}

    public void saveRoom(Room room){roomR.save(room);}

    public void deleteRoom(Long roomId) {
        roomR.deleteById(roomId);
    }

}
