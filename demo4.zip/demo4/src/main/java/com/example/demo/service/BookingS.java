package com.example.demo.service;

import com.example.demo.model.Booking;

import com.example.demo.repository.BookingR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingS {
    private final BookingR bookingR;

    @Autowired
    public BookingS(BookingR bookingR){this.bookingR=bookingR;}

    public List<Booking> getBookings(){
        return bookingR.findAll();
    }

    public void saveBooking(Booking booking){
        bookingR.save(booking);
    }


    public void deleteBooking(Long bookingId) {
        bookingR.deleteById(bookingId);
    }
}
