package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Entity@Table(name = "customer")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String name;
    private String phoneNo;
    private String email;
    private String password;
    private String confirm_password;

    public Customer() {
    }

    public Customer(long id, String name, String email, String phoneNo, String password, String confirm_password) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phoneNo=phoneNo;
        this.password = password;
        this.confirm_password = confirm_password;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirm_password() {
        return confirm_password;
    }

    public void setConfirm_password(String confirm_password) {
        this.confirm_password = confirm_password;
    }


  /*  @OneToOne
    @JoinColumn(name = "user_id")
    private UserM userM;

    @ManyToMany
    @JoinTable(
            name = "user_customer",
            joinColumns = @JoinColumn(name = "customer_id"),
            inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private Set<UserM> userMS = new HashSet<>();*/
}
