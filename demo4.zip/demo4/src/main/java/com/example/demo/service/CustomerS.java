package com.example.demo.service;

import com.example.demo.model.Customer;
import com.example.demo.repository.CustomerR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerS {
    private final CustomerR customerR;

    @Autowired
    public CustomerS(CustomerR customerR){
        this.customerR = customerR;
    }

    public List<Customer> getCustomers(){
        return customerR.findAll();
    }

    public void saveCustomer(Customer customer){
        customerR.save(customer);
    }

    public void deleteCustomer(Long customerId) {
        customerR.deleteById(customerId);
    }

    public Customer customer_login(String email, String password){
        Customer customer = customerR.findByEmailAndPassword(email,password);
        return customer;
    }


}
