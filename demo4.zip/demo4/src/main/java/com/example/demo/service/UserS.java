package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.repository.UserR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserS {

    private final UserR userR;

    @Autowired
    public UserS(UserR userR){
        this.userR = userR;
    }

    public List<User> getUsers(){
        return userR.findAll();
    }

    public void saveUser(User user){
        userR.save(user);
    }



    public User login(String email, String password){
        User user = userR.findByEmailAndPassword(email,password);
        return user;
    }

    public User getUserById(Long id) {
        // Use the findById method provided by Spring Data JPA
        Optional<User> userOptional = userR.findById(id);

        // Check if the user with the specified ID exists
        if (userOptional.isPresent()) {
            return userOptional.get();
        } else {
            // Handle the case where the user is not found
            throw new RuntimeException("User not found with ID: " + id);
        }
    }

    public void updateUser(User updatedUser) {
        Optional<User> existingUserOptional = userR.findById(updatedUser.getId());

        if (existingUserOptional.isPresent()) {
            User existingUser = existingUserOptional.get();

            // Update the fields you want to allow changing
            existingUser.setName(updatedUser.getName());
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setPassword(updatedUser.getPassword());
            existingUser.setAddress(updatedUser.getAddress());

            // Save the updated user to the database
            userR.save(existingUser);
        } else {
            // Handle the case where the user with the specified ID is not found
            throw new RuntimeException("User not found with ID: " + updatedUser.getId());
        }
    }
}
