package com.example.demo.service;

import com.example.demo.model.Staff;
import com.example.demo.repository.StaffR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StaffS {

    private final StaffR staffR;

    @Autowired
    public StaffS(StaffR staffR){this.staffR=staffR;}

    public List<Staff> getStaffs(){
        return staffR.findAll();
    }

    public void saveStaff(Staff staff){
        staffR.save(staff);
    }


    public void deleteStaff(Long staffId) {
        staffR.deleteById(staffId);
    }
}
