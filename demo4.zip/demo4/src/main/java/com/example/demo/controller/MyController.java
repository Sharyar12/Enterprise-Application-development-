package com.example.demo.controller;


import com.example.demo.model.*;
import com.example.demo.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import java.util.List;
import java.util.Objects;




@Controller
    public class MyController {
        @Autowired
        CustomerS customerS;
        @Autowired
        UserS userS;
        @Autowired
        RoomS roomS;
        @Autowired
        BookingS bookingS;
        @Autowired
        StaffS staffS;




    @GetMapping("index")
    public String showIndex(){
        return "index";
    }

   @GetMapping("addbooking")
   public String addbooking(Model model){
       List<Booking> bookings=bookingS.getBookings();
       model.addAttribute("bookings",bookings);
       model.addAttribute("newBooking",new Booking());
       return "addbooking";
   }

   @PostMapping("addbooking")
   public String addbooking(@ModelAttribute("newBooking") Booking newBooking){
       bookingS.saveBooking(newBooking);
       return "redirect:/allbooking";
   }



    @GetMapping("addcustomer")
    public String showaddcustomer(Model model)
    {
        List<Customer> customers =customerS.getCustomers();
        model.addAttribute("customers", customers);
        model.addAttribute("newCustomer",new Customer());
        return "addcustomer";
    }

    @PostMapping("addcustomer")
    public String addcustomer(@ModelAttribute("newCustomer") Customer newCustomer){
        customerS.saveCustomer(newCustomer);
        return "redirect:/allcustomer";
    }



    @GetMapping("addroom")
    public String showaddroom(Model model)
    {
        List<Room> rooms = roomS.getRooms();
        model.addAttribute("rooms",rooms);
        model.addAttribute("newRoom",new Room());
        return "addroom";
    }
    @PostMapping("addroom")
    public String addroom(@ModelAttribute("newRoom") Room newRoom){
        roomS.saveRoom(newRoom);
        return "redirect:/allrooms";
    }
    @PostMapping("/deleteRoom/{roomId}")
    public String deleteRoom(@PathVariable Long roomId) {
        roomS.deleteRoom(roomId);
        return "redirect:/allroom";
    }



    @GetMapping("addsalary")
    public String addsalary(){
        return "addsalary";
    }
    @GetMapping("addstaff")
    public String addstaff(Model model){
        List<Staff> staff =staffS.getStaffs();
        model.addAttribute("staff", staff);
        model.addAttribute("newStaff",new Staff());
        return "addstaff";
    }
    @PostMapping("addstaff")
    public String addstaff(@ModelAttribute("newStaff") Staff newStaff){
        staffS.saveStaff(newStaff);
        return "redirect:/allstaff";
    }


    @GetMapping("allbooking")
    public String allbooking(Model model){
        List<Booking> bookings =bookingS.getBookings();
        System.out.println(bookings);
        model.addAttribute("Bookings", bookings);
        return "allbooking";
    }
    @PostMapping("/deleteStaff/{staffId}")
    public String deleteStaff(@PathVariable Long staffId) {
        staffS.deleteStaff(staffId);
        return "redirect:/allstaff";
    }



    @PostMapping("/deleteBooking/{bookingId}")
    public String deleteBooking(@PathVariable Long bookingId) {
        bookingS.deleteBooking(bookingId);
        return "redirect:/allbooking";
    }





    @GetMapping("allcustomer")
    public String allcustomer(Model model)
    {
        List<Customer> customers =customerS.getCustomers();
        System.out.println(customers);
        model.addAttribute("Customers", customers);
        return "allcustomer";
    }



    @GetMapping("allrooms")
    public String allrooms(Model model)
    {
        List<Room> rooms =roomS.getRooms();
        System.out.println(rooms);
        model.addAttribute("Rooms", rooms);
        return "allrooms";
    }
    @GetMapping("allstaff")
    public String allstaff(Model model)
    {
        List<Staff> staff =staffS.getStaffs();
        System.out.println(staff);
        model.addAttribute("Staffs", staff);
        return "allstaff";
    }
    @GetMapping("blankpage")
    public String blankpage(){
        return "blankpage";
    }
    @GetMapping("changepassword")
    public String changepassword(){
        return "changepassword";
    }
    @GetMapping("editbooking")
    public String editbooking(){
        return "editbooking";
    }
    @GetMapping("editcustomer")
    public String editcustomer(){
        return "editcustomer";
    }
    @GetMapping("editprofile")
    public String editprofile()
    {
        return "editprofile";
    }
    @GetMapping("editroom")
    public String editroom(){
        return "editroom";
    }
    @GetMapping("editsalary")
    public String editsalary(){
        return "editsalary";
    }
    @GetMapping("editstaff")
    public String editstaff(){
        return "editstaff";
    }
    @GetMapping("employee")
    public String employee(){
        return "employee";
    }
    @GetMapping("error404")
    public String error404(){
        return "error404";
    }
    @GetMapping("error500")
    public String error500(){
        return "error500";
    }
    @GetMapping("forgotpassword")
    public String forgotpassword(){
        return "forgotpassword";
    }
    @GetMapping("formbasicinputs")
    public String formbasicinputs(){
        return "formbasicinputs";
    }
    @GetMapping("formhorizontal")
    public String formhorizontal(){
        return "formhorizontal";
    }
    @GetMapping("forminputgroups")
    public String forminputgroups(){
        return "forminputgroups";
    }
    @GetMapping("formvertical")
    public String formvertical(){
        return "formvertical";
    }
    @GetMapping("gallery")
    public String gallery(){
        return "gallery";
    }
    @GetMapping("lockscreen")
    public String lockscreen(){
        return "lockscreen";
    }

    @GetMapping("welcome")
    public String welcome(){
        return "welcome";
    }


    @GetMapping("login")
    public ModelAndView login()
    {
        ModelAndView mav = new ModelAndView("login");
        mav.addObject("user",new User());

        return mav;
    }

    @PostMapping("login")
    public String login(@ModelAttribute("user") User user) {
        User oauthUser = this.userS.login(user.getEmail(), user.getPassword());
        System.out.print(oauthUser);
        if (Objects.nonNull(oauthUser)) {
            return "redirect:/";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("profile")
    public String profile(Model model){
        List<User> users=userS.getUsers();
        model.addAttribute("users",users);
        return "profile";
    }


    @GetMapping("register")

    public String register(Model model){
        model.addAttribute("user",new User());
        return "register";
    }
    @PostMapping("/register")
    public String register(@ModelAttribute("user") User user){
        this.userS.saveUser(user);
        return "redirect:/login";
    }


    @GetMapping("salary")
    public String salary(){
        return "salary" ;
    }
    @GetMapping("salarysettings")
    public String salarysettings(){
        return "salarysettings";
    }
    @GetMapping("salaryveiw")
    public String salaryview(){
        return "salaryveiw";
    }
    @GetMapping("settings")
    public String settings(){
        return "settings";
    }
    @GetMapping("themesettings")
    public String themesettings(){
        return "themesettings";
    }


}
