package com.example.demo.controller;

import com.example.demo.model.Booking;
import com.example.demo.model.Customer;
import com.example.demo.model.Room;
import com.example.demo.service.BookingS;
import com.example.demo.service.CustomerS;
import com.example.demo.service.RoomS;
import com.example.demo.service.UserS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import java.util.List;
import java.util.Objects;

@Controller
public class CustomerController {

    @Autowired
    CustomerS customerS;
    @Autowired
    UserS userS;
    @Autowired
    RoomS roomS;
    @Autowired
    BookingS bookingS;

    @GetMapping("customer_login")
    public ModelAndView customer_login()
    {
        ModelAndView mav = new ModelAndView("customer_login");
        mav.addObject("customer",new Customer());
        return mav;
    }

    @PostMapping("customer_login")
    public String customer_login(@ModelAttribute("customer") Customer customer) {
        Customer oauthCustomer = customerS.customer_login(customer.getEmail(), customer.getPassword());
        System.out.print(oauthCustomer);
        if (Objects.nonNull(oauthCustomer)) {
            return "redirect:/customerindex";
        } else {
            return "redirect:/customer_login";
        }
    }

    @PostMapping("/deleteCustomer/{customerId}")
    public String deleteCustomer(@PathVariable Long customerId) {
        customerS.deleteCustomer(customerId);
        return "redirect:/allcustomer";
    }

    @PostMapping("/deleteCBooking/{bookingId}")
    public String deleteBooking(@PathVariable Long bookingId) {
        bookingS.deleteBooking(bookingId);
        return "redirect:/customer_addbooking";
    }



    @GetMapping("availablerooms")
    public String allrooms(Model model)
    {
        List<Room> rooms =roomS.getRooms();
        System.out.println(rooms);
        model.addAttribute("Rooms", rooms);
        return "availablerooms";
    }

    @GetMapping("customerindex")
    public String customerindex(){return "customerindex";}

    @GetMapping("customer_profile")
    public String customerprofile(Model model){
        List<Customer>customers=customerS.getCustomers();
        model.addAttribute("customer",customers);
        return "customer_profile";
    }

    @GetMapping("customer_editprofile")
    public String allstaff(){
        return "customer_editprofile";
    }

    @GetMapping("customer_register")

    public String register(Model model){
        model.addAttribute("customer",new Customer());
        return "customer_register";
    }
    @PostMapping("/customer_register")
    public String register(@ModelAttribute("customer") Customer customer){
        customerS.saveCustomer(customer);
        return "redirect:/customer_login";
    }

    @GetMapping("customer_addbooking")
    public String customeraddbooking(Model model){
        List<Booking> bookings=bookingS.getBookings();
        model.addAttribute("bookings",bookings);
        model.addAttribute("newBooking",new Booking());
        model.addAttribute("Bookings", bookings);
        return "customer_addbooking";
    }

    @PostMapping("customer_addbooking")
    public String customeraddbooking(@ModelAttribute("newBooking") Booking newBooking){
        bookingS.saveBooking(newBooking);
        return "redirect:/customer_addbooking";
    }

}
